import dataiku

import pandas as pd
import plotly.express as px

import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output

# READ DATASET
dataset = dataiku.Dataset("Orders_by_Country_sorted")
df = dataset.get_dataframe()

# DEFINE STYLES

main_style = {
    'background': '#FFFFFF',
    'font-family': "Arial"
}

title_style = {
    'background': '#5473FF',
    'text': '#FFFFFF'
}

desc_style = {
    'background': '#FFFFFF',
    'text': '5473FF'
}
dropdown_style = {
    'background': '#DDE5ED',
    'text': '#221C35'
}

# build your Dash app
app.layout = html.Div(# DEFINE APP LAYOUT
app.layout = html.Div(
    ## Step 1: Define App Style
    style={
        'backgroundColor': main_style['background'],
        'font-family': main_style['font-family']
    },
)## Step 2: Create Title & Description
children=[
    html.H1(
        children='Total Sales by Country',
        style={
            'backgroundColor': title_style['background'],
            'color': title_style['text'],
            'textAlign': 'center'}
    ),
    html.Div(
        children='This graph allows you to compare the total sales amount and campaign influence by country.',
        style={
            'backgroundColor': desc_style['background'],
            'color': desc_style['text'],
            'textAlign': 'center'}
    ),
])