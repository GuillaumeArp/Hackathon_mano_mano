# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
main_dataset = dataiku.Dataset("main_dataset")
main_dataset_df = main_dataset.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

percentage_score_per_date_df = main_dataset_df # For this sample code, simply copy input to output


pivot_date = percentage_score_per_date_df.pivot_table(index='date', columns='Customer_Effort_Score_category', values='id', aggfunc='count', margins = True)
pivot_date.drop(pivot_date.tail(1).index,inplace=True)
pivot_date['detractor_percentage'] = round(pivot_date["Detractor"] / pivot_date['All'] * 100, 2)
pivot_date['promotor_percentage'] = round(pivot_date["Promoter"] / pivot_date['All'] * 100, 2)
pivot_date['NPS_score'] = pivot_date["promotor_percentage"] - pivot_date["detractor_percentage"]
pivot_date.reset_index(inplace = True)
percentage_score_per_date_df = pivot_date

# Write recipe outputs
percentage_score_per_date = dataiku.Dataset("percentage_score_per_date")
percentage_score_per_date.write_with_schema(percentage_score_per_date_df)
